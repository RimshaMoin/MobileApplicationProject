package com.example.complainapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.MenuItem;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class ReportShow extends AppCompatActivity {


        DatabaseHelper helpher;
        List<User> dbList;
        RecyclerView mRecyclerView;
        private RecyclerView.Adapter mAdapter;
        private RecyclerView.LayoutManager mLayoutManager;

        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_report_show);

            getSupportActionBar().hide();


            helpher = new DatabaseHelper(this);
            dbList= new ArrayList<User>();
            dbList = helpher.getDataFromDB();


            mRecyclerView = (RecyclerView)findViewById(R.id.recycleview);

            mRecyclerView.setHasFixedSize(true);

            // use a linear layout manager
            mLayoutManager = new LinearLayoutManager(this);
            mRecyclerView.setLayoutManager(mLayoutManager);

            // specify an adapter (see also next example)
            mAdapter = new RecyclerAdapter(this,dbList);
            mRecyclerView.setAdapter(mAdapter);

        }





        public boolean onOptionsItemSelected(MenuItem item) {
            switch (item.getItemId()) {
                case android.R.id.home:
                    finish();
                    return true;
            }
            return super.onOptionsItemSelected(item);
        }
    }

