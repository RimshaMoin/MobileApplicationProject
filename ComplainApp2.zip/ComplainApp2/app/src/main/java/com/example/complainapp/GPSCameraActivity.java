package com.example.complainapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class GPSCameraActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gpscamera);
    }
}
