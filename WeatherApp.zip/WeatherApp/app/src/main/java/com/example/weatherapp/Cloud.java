package com.example.weatherapp;

public class Cloud {
    private int all;

    public Cloud(int all) {
        this.all = all;
    }

    public int getAll() {
        return all;
    }

    public void setAll(int all) {
        this.all = all;
    }
}
