package com.example.weatherapp;

import java.util.List;

public class OpenWeatherMap {
    private Coord coord;
    private List<Weather> weather;
    private String base;
    private Main main;
    private Sys sys;
    private Wind wind;
    private Cloud cloud;
    private int id;
    private String name;
    private int cod;
    private int dt;
    private int visibility;
    private int timezone;

    public OpenWeatherMap() {
    }

    public OpenWeatherMap(Coord coord, List<Weather> weather, String base, Main main, Sys sys, Wind wind, Cloud cloud, int id, String name, int cod, int dt, int visibility, int timezone) {
        this.coord = coord;
        this.weather = weather;
        this.base = base;
        this.main = main;
        this.sys = sys;
        this.wind = wind;
        this.cloud = cloud;
        this.id = id;
        this.name = name;
        this.cod = cod;
        this.dt = dt;
        this.visibility = visibility;
        this.timezone = timezone;
    }

    public Coord getCoord() {
        return coord;
    }

    public void setCoord(Coord coord) {
        this.coord = coord;
    }

    public List<Weather> getWeather() {
        return weather;
    }

    public void setWeather(List<Weather> weather) {
        this.weather = weather;
    }

    public String getBase() {
        return base;
    }

    public void setBase(String base) {
        this.base = base;
    }

    public Main getMain() {
        return main;
    }

    public void setMain(Main main) {
        this.main = main;
    }

    public Sys getSys() {
        return sys;
    }

    public void setSys(Sys sys) {
        this.sys = sys;
    }

    public Wind getWind() {
        return wind;
    }

    public void setWind(Wind wind) {
        this.wind = wind;
    }

    public Cloud getCloud() {
        return cloud;
    }

    public void setCloud(Cloud cloud) {
        this.cloud = cloud;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getCod() {
        return cod;
    }

    public void setCod(int cod) {
        this.cod = cod;
    }

    public int getDt() {
        return dt;
    }

    public void setDt(int dt) {
        this.dt = dt;
    }

    public int getVisibility() {
        return visibility;
    }

    public void setVisibility(int visibility) {
        this.visibility = visibility;
    }

    public int getTimezone() {
        return timezone;
    }

    public void setTimezone(int timezone) {
        this.timezone = timezone;
    }
}
